import euclidian_algorithm.EuclidianAlgorithm;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class GCDTest {

    @Test
    public void testGCDOfPositiveNumbers() {
        assertEquals(6, EuclidianAlgorithm.euclid(54, 24));
        assertEquals(1, EuclidianAlgorithm.euclid(17, 31));
        assertEquals(5, EuclidianAlgorithm.euclid(10, 5));
        assertEquals(1, EuclidianAlgorithm.euclid(101, 10));
    }

    @Test
    public void testGCDWithZero() {
        assertEquals(7, EuclidianAlgorithm.euclid(7, 0));
        assertEquals(7, EuclidianAlgorithm.euclid(0, 7));
        assertEquals(0, EuclidianAlgorithm.euclid(0, 0)); // may throw or return 0 depending on convention
    }

    @Test
    public void testGCDWithEqualNumbers() {
        assertEquals(9, EuclidianAlgorithm.euclid(9, 9));
    }

    @Test
    public void testGCDWithNegativeNumbers() {
        assertEquals(4, EuclidianAlgorithm.euclid(-8, 12));
        assertEquals(8, EuclidianAlgorithm.euclid(8, -24));
        assertEquals(4, EuclidianAlgorithm.euclid(-8, -12));
    }

    @Test
    public void testLargeNumbers() {
        assertEquals(1, EuclidianAlgorithm.euclid(123456789, 98765432));
    }
}
