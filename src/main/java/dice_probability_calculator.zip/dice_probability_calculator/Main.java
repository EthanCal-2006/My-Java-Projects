package dice_probability_calculator;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask for target value
        System.out.print("What value must you equal or exceed for this roll?: ");
        int userValue = Integer.parseInt(scanner.nextLine());

        // Collect selected dice
        List<Integer> selectedDice = new ArrayList<>();

        System.out.print("Do you have a D4? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(4);

        System.out.print("Do you have a D6? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(6);

        System.out.print("Do you have a D8? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(8);

        System.out.print("Do you have a D10? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(10);

        System.out.print("Do you have a D12? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(12);

        System.out.print("Do you have a D20? (Y/N): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) selectedDice.add(20);

        // Compute total possible combinations
        int possibleOutcomes = 1;
        for (int sides : selectedDice) {
            possibleOutcomes *= sides;
        }

        // Handle case where no dice are selected
        if (selectedDice.isEmpty()) {
            System.out.println("No dice selected. Exiting.");
            return;
        }

        // Compute favorable outcomes
        int favorableOutcomes = countFavorableOutcomes(selectedDice, userValue);

        // Output results
        System.out.println("\nTotal possible outcomes: " + possibleOutcomes);
        System.out.println("The total Favorable outcomes: " + favorableOutcomes);

        double probability = (double) favorableOutcomes / possibleOutcomes * 100;
        System.out.printf("The odds of tying or exceeding the threshold (" + userValue + ") is: %.2f%%\n", probability);
    }

    // Updated to accept List<Integer>
    public static int countFavorableOutcomes(List<Integer> diceSides, int targetSum) {
        Map<Integer, Integer> dp = new HashMap<>();
        dp.put(0, 1); // base case

        for (int sides : diceSides) {
            Map<Integer, Integer> newDp = new HashMap<>();
            for (Map.Entry<Integer, Integer> entry : dp.entrySet()) {
                int currentSum = entry.getKey();
                int ways = entry.getValue();

                for (int face = 1; face <= sides; face++) {
                    int newSum = currentSum + face;
                    newDp.put(newSum, newDp.getOrDefault(newSum, 0) + ways);
                }
            }
            dp = newDp;
        }

        // Sum all ways where sum >= target
        int count = 0;
        for (Map.Entry<Integer, Integer> entry : dp.entrySet()) {
            if (entry.getKey() >= targetSum) {
                count += entry.getValue();
            }
        }
        return count;
    }
}
